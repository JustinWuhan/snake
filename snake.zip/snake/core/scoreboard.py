
class Scoreboard(object):
    def __init__(self):
        self.score = 0

    def inc_score(self):
        self.score+=1
